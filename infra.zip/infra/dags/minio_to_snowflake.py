import os
import boto3
import snowflake.connector
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

# --- CONNECTION VARIABLES ---
MINIO_ENDPOINT = "http://minio:9000"
MINIO_ACCESS_KEY = "admin"
MINIO_SECRET_KEY = "password123"
BUCKET = "bronze-transactions"
LOCAL_DIR = "/tmp/minio_downloads"

# Snowflake Credentials
SNOWFLAKE_USER = "ayush647"
SNOWFLAKE_PASSWORD = "Pr@tyush123456"
SNOWFLAKE_ACCOUNT = "rf33021.eu-west-2.aws"
SNOWFLAKE_WAREHOUSE = "COMPUTE_WH"
SNOWFLAKE_DB = "STOCKS_MDS"
SNOWFLAKE_SCHEMA = "COMMON"
# Target Table Name
TARGET_TABLE = "bronze_stock_quotes_raw"

def download_from_minio():
    """
    Downloads files from MinIO to local Airflow temp storage.
    """
    os.makedirs(LOCAL_DIR, exist_ok=True)
    
    s3 = boto3.client(
        "s3",
        endpoint_url=MINIO_ENDPOINT,
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY
    )
    
    # List objects
    response = s3.list_objects_v2(Bucket=BUCKET)
    objects = response.get("Contents", [])
    local_files = []

    if not objects:
        print("INFO: Bucket is empty. No files to process.")
        return []

    for obj in objects:
        key = obj["Key"]
        if key.endswith('/'): continue # Skip folders
        
        # Create unique local filename
        safe_name = key.replace('/', '_')
        local_file = os.path.join(LOCAL_DIR, safe_name)
        
        # Download
        s3.download_file(BUCKET, key, local_file)
        print(f"Downloaded: {local_file}")
        local_files.append(local_file)
        
    return local_files

def load_to_snowflake(**kwargs):
    """
    Uploads files to Snowflake internal table stage and runs COPY INTO.
    """
    # Get list of files from the previous task
    local_files = kwargs['ti'].xcom_pull(task_ids='download_minio')
    
    if not local_files:
        print("No files to load.")
        return

    print(f"Connecting to Snowflake as {SNOWFLAKE_USER}...")

    # Connect to Snowflake with ACCOUNTADMIN role explicitly
    conn = snowflake.connector.connect(
        user=SNOWFLAKE_USER,
        password=SNOWFLAKE_PASSWORD,
        account=SNOWFLAKE_ACCOUNT,
        warehouse=SNOWFLAKE_WAREHOUSE,
        database=SNOWFLAKE_DB,
        schema=SNOWFLAKE_SCHEMA,
        role='ACCOUNTADMIN'  # <--- FORCE POWERFUL ROLE
    )
    cur = conn.cursor()

    try:
        # 1. Force Context (Critical Step)
        print("Setting session context...")
        cur.execute(f"USE WAREHOUSE {SNOWFLAKE_WAREHOUSE}")
        cur.execute(f"USE DATABASE {SNOWFLAKE_DB}")
        cur.execute(f"USE SCHEMA {SNOWFLAKE_SCHEMA}")

        # 2. PUT files into the Table's Internal Stage
        # Syntax: @%Table_Name
        for f in local_files:
            print(f"Uploading {f}...")
            put_cmd = f"PUT file://{f} @%{TARGET_TABLE} AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
            cur.execute(put_cmd)
        
        # 3. COPY INTO the Table from the Table's Internal Stage
        print("Running COPY INTO...")
        copy_cmd = f"""
            COPY INTO {TARGET_TABLE}
            FROM @%{TARGET_TABLE}
            FILE_FORMAT = (TYPE=JSON)
            ON_ERROR = 'CONTINUE'
        """
        cur.execute(copy_cmd)
        print("Data loaded successfully!")

        # 4. Cleanup (Remove files from stage)
        cur.execute(f"REMOVE @%{TARGET_TABLE}")
        print("Stage cleaned.")

    except Exception as e:
        print(f"ERROR: {e}")
        raise e
    finally:
        cur.close()
        conn.close()

# --- DAG DEFINITION ---
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2025, 12, 5),
    "retries": 1,
    "retry_delay": timedelta(minutes=1),
}

with DAG(
    "minio_to_snowflake",
    default_args=default_args,
    schedule_interval="*/1 * * * *",
    catchup=False,
) as dag:

    t1 = PythonOperator(
        task_id="download_minio",
        python_callable=download_from_minio,
    )

    t2 = PythonOperator(
        task_id="load_snowflake",
        python_callable=load_to_snowflake,
        provide_context=True,
    )

    t1 >> t2